<div class="box-body">  
        <style type="text/css">
            .display-no
            {
                display: none;
            }
        </style>
        <div class="box-header">
                <table class="data-table table table-bordered table-hover display nowrap" id="table" class="display nowrap" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th><h3>Todas las Categorias</h3></th>
                        </tr>
                        <tr>
                            
                            <th style="background-color:#3c8dbc; color:#fff">Nro Factura</th>
                            <th style="background-color:#3c8dbc; color:#fff">Tipo Compra</th>
                            <th style="background-color:#3c8dbc; color:#fff">Proveedor</th>
                            <th style="background-color:#3c8dbc; color:#fff">Fecha</th>
                            <th style="background-color:#3c8dbc; color:#fff">Monto Total</th>
                            <th style="background-color:#3c8dbc; color:#fff">Total Pagado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                    </tr>
                    </tfoot>
                </table>
        </div>
    
</div>