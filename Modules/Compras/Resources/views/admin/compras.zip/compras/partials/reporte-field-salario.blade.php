<div class="box-body">  
        <style type="text/css">
            .display-no
            {
                display: none;
            }
        </style>
        <div class="box-header">
                <table class="data-table table table-bordered table-hover display nowrap" id="table" class="display nowrap" cellspacing="0" width="100%">
                    <thead>
                        <tr>

                            <th><h3>{{ucfirst($categorias)}}</h3></th>

                        </tr>
                        <tr>
                            
                            <th style="background-color:#3c8dbc; color:#fff">Nombre</th>
                            <th style="background-color:#3c8dbc; color:#fff">Apellido</th>
                            <th style="background-color:#3c8dbc; color:#fff">Salario Neto</th>
                            <th style="background-color:#3c8dbc; color:#fff">Monto IPS</th>
                            <th style="background-color:#3c8dbc; color:#fff">Extras</th>
                            <th style="background-color:#3c8dbc; color:#fff">Total Pagado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                        <th style="background-color:#3c8dbc; color:#fff"></th>
                    </tr>
                    </tfoot>
                </table>
        </div>
    
</div>