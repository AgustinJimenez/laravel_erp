@extends('layouts.master')

@section('content-header')
    <h1>
        Libro Mayor
    </h1>
    
@stop

@section('content')
    <style type="text/css">
        .to_historial{ cursor: pointer; cursor: hand; }
    </style>
    <div class="row">
        <div class="col-xs-12">
            <div class="row">
                <div class="btn-group pull-right" style="margin: 0 15px 15px 0; display: inline;">


                </div>
            </div>
            <div class="box box-primary">
                <div class="box-header">

                    {!! Form::open(array('route' => ['admin.contabilidad.reportes.libro_mayor_index'],'method' => 'post', 'id' => 'search-form')) !!}

                        <div class="col-md-2">
                            <label for="razon_social" class="control-label" >Codigo:   </label>
                            <input type="text" class="form-control input-sm codigo" name="codigo" id="codigo" value="" >
                        </div>

                        <div class="col-md-2">
                            <label for="marca">Tipo: </label>
                            <select class="form-control tipo" id="tipo" name="tipo">
                                <option value='' selected>--</option>
                                @foreach($tipos as $tipo)
                                    <option value='{{ $tipo->nombre }}'>{{ $tipo->nombre }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-2">
                            <label for="razon_social" class="control-label" >Nombre:   </label>
                            <input type="text" class="form-control input-sm nombre" name="nombre" id="nombre" value="" >
                        </div>

                        <div class="col-md-2">
                            <table>
                                <tr>
                                    <td>
                                        {!! Form::normalInput('fecha_desde', 'Fecha Desde:', $errors, (object)['fecha_desde' => "01/01/".Session::get('ejercicio')]) !!}
                                    </td>
                                    <td>
                                        <button class="btn btn-flat form-control" data-toggle="modal" id="borrar_fecha_desde" style=""><i class="fa fa-trash" style=""></i></button>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <div class="col-md-2">
                            <table>
                                <tr>
                                    <td>
                                        {!! Form::normalInput('fecha_hasta', 'Fecha Hasta:', $errors, (object)['fecha_hasta' => "31/12/".Session::get('ejercicio')]) !!}
                                    </td>
                                    <td>
                                        <button class="btn btn-flat form-control" data-toggle="modal" id="borrar_fecha_hasta" style=""><i class="fa fa-trash" style=""></i></button>
                                    </td>
                                </tr>
                            </table>
                        </div>

                    {!! Form::close() !!}
                        <div class="col-md-2">

                            {!! Form::open(array('route' => ['admin.contabilidad.reportes.libro_mayor_pdf'],'method' => 'post', 'id' => 'form_report_pdf', 'target=' => '_blank')) !!}

                                {!! Form::hidden('fecha_inicio_pdf') !!} {!! Form::hidden('fecha_fin_pdf') !!}

                                    <button type="submit" class="btn btn-danger" >
                                        <i class="fa fa-book"></i> {{ trans('Exportar a PDF&nbsp;&nbsp; ') }}
                                    </button>

                            {!! Form::close() !!}
                        
                            {!! Form::open(array('route' => ['admin.contabilidad.reportes.libro_mayor_xls'],'method' => 'post', 'id' => 'form_report_xls', 'target=' => '_blank')) !!}

                                {!! Form::hidden('fecha_inicio_xls') !!} {!! Form::hidden('fecha_fin_xls') !!}

                                    <button type="submit" class="btn btn-success" >
                                        <i class="fa fa-book"></i> {{ trans('Exportar a Excel') }}
                                    </button>

                            {!! Form::close() !!}
                        </div>
                        

                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table class="data-table table table-bordered table-hover" style="width:100%;">
                        <thead>
                        <tr>
                            <th style="background-color:#3c8dbc; color:#fff">Codigo</th>
                            <th style="background-color:#3c8dbc; color:#fff">Tipo</th>
                            <th style="background-color:#3c8dbc; color:#fff">Nombre</th>
                            <th style="background-color:#3c8dbc; color:#fff">DEBE</th>
                            <th style="background-color:#3c8dbc; color:#fff">HABER</th>
                            <th style="background-color:#3c8dbc; color:#fff">SALDO</th>
                        </tr>
                        </thead>
                        <tbody>

                            <tr>

                                <td></td>

                                <td></td>

                                <td></td>

                                <td></td>

                                <td></td>

                                <td></td>

                            </tr>

                        </tbody>
                        <tfoot>
                        <tr>
                            <th style="background-color:#3c8dbc; color:#fff">Codigo</th>
                            <th style="background-color:#3c8dbc; color:#fff">Tipo</th>
                            <th style="background-color:#3c8dbc; color:#fff">Nombre</th>
                            <th style="background-color:#3c8dbc; color:#fff">DEBE</th>
                            <th style="background-color:#3c8dbc; color:#fff">HABER</th>
                            <th style="background-color:#3c8dbc; color:#fff">SALDO</th>
                        </tr>
                        </tfoot>
                    </table>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </div>
    @include('core::partials.delete-modal')
@stop

@section('footer')
    <a data-toggle="modal" data-target="#keyboardShortcutsModal"><i class="fa fa-keyboard-o"></i></a> &nbsp;
@stop
@section('shortcuts')
    <dl class="dl-horizontal">
        <dt><code>c</code></dt>
        <dd>{{ trans('contabilidad::cuentas.title.create cuenta') }}</dd>
    </dl>
@stop

@section('scripts')
    
    {!! Theme::style('css/bootstrap-datetimepicker.min.css') !!}
    {!! Theme::script('js/moment.js') !!}
    {!! Theme::script('js/moment.es.js') !!}
    {!! Theme::script('js/bootstrap-datetimepicker.min.js') !!}
    {!! Theme::script('js/bootstrap-datetimepicker.es.js') !!}

    <?php $locale = locale(); ?>
    <script type="text/javascript">
        var count=0;
        $(function () 
        {
            $(document).on('click', 'a.to_historial', function()
            {
                var fecha_desde = $("#fecha_desde");

                var fecha_hasta = $("#fecha_hasta");

                $(this).closest('tr').find('input[name=fecha_inicio_historial]').val( fecha_desde.val() );

                $(this).closest('tr').find('input[name=fecha_fin_historial]').val( fecha_hasta.val() );

                $(this).closest('tr').find('form').submit();
            });

            $("#form_report_xls").submit(function()
            {
                var fecha_desde = $("#fecha_desde");

                var fecha_hasta = $("#fecha_hasta");

                var fecha_inicio_xls = $("input[name=fecha_inicio_xls]");

                var fecha_fin_xls = $("input[name=fecha_fin_xls]");

                fecha_inicio_xls.val( fecha_desde.val() );

                fecha_fin_xls.val( fecha_hasta.val() );
            });

            $("#form_report_pdf").submit(function()
            {
                var fecha_desde = $("#fecha_desde");

                var fecha_hasta = $("#fecha_hasta");

                var fecha_inicio_xls = $("input[name=fecha_inicio_pdf]");

                var fecha_fin_xls = $("input[name=fecha_fin_pdf]");

                fecha_inicio_xls.val( fecha_desde.val() );

                fecha_fin_xls.val( fecha_hasta.val() );
            });

            $('#fecha_desde').click(function()
            {
                $("#search-form").submit();
            });

            $('#fecha_hasta').click(function()
            {
                $("#search-form").submit();
            });

            $('#fecha_desde').datetimepicker(
            {
                format: 'DD/MM/YYYY',
                //format: 'YYYY-MM-DD',
                locale: 'es'
            });

            $('#fecha_hasta').datetimepicker(
            {
                format: 'DD/MM/YYYY',
                //format: 'YYYY-MM-DD',
                locale: 'es'
            });

            $("#fecha_desde").on("dp.change", function (e) 
            {
                $("#search-form").submit();
            });

            $("#fecha_hasta").on("dp.change", function (e) 
            {
                $("#search-form").submit();
            });

            $('#borrar_fecha_desde').click(function()
            {
                $('#fecha_desde').val('');
                $("#search-form").submit();
                
            });

            $('#borrar_fecha_hasta').click(function()
            {
                $('#fecha_hasta').val('');
                $("#search-form").submit();
            });

            $("#codigo").on("keyup",function()
            {
                $("#search-form").submit();
            });

            $("#tipo").on("change",function()
            {
                $("#search-form").submit();
            });

            $("#nombre").on("keyup",function()
            {
                $("#search-form").submit();
            });

            $('#search-form').on('submit', function(e) 
            {
                table.draw();
                e.preventDefault();
            });

            var table = $('.data-table').DataTable(
            {
                dom: "<'row'<'col-xs-12'<'col-xs-6'l><'col-xs-6'p>>r>"+
                "<'row'<'col-xs-12't>>"+
                "<'row'<'col-xs-12'<'col-xs-6'i><'col-xs-6'p>>>",

                "deferRender": true,
                processing: false,
                serverSide: true,
                "paginate": true,
                "lengthChange": true,
                 "iDisplayLength": 25,
                "filter": true,
                "sort": true,
                "info": true,
                "autoWidth": true,
                "paginate": true,
                ajax: 
                {
                    url: '{!! route('admin.contabilidad.reportes.libro_mayor_index') !!}',
                    type: "GET",
                    headers: {'X-CSRF-TOKEN': '{{ csrf_token() }}'},
                    data: function (d) 
                    {
                        d.codigo = $('#codigo').val();

                        d.tipo_nombre = $('#tipo').val();

                        d.nombre = $('#nombre').val();

                        d.fecha_desde = $('#fecha_desde').val();

                        d.fecha_hasta = $('#fecha_hasta').val();
                    }
                },
                columns: 
                [
                    { data: 'codigo', name: 'codigo' },
                    { data: 'tipo_nombre', name: 'tipo_nombre' },
                    { data: 'nombre', name: 'nombre' },
                    { data: 'debe', name: 'debe'},  
                    { data: 'haber', name: 'haber'},
                    { data: 'saldo', name: 'saldo'}
                    //{ data: 'action', name: 'action', orderable: false, searchable: false}  
                ],
                language: {
                    processing:     "Procesando...",
                    search:         "Buscar",
                    lengthMenu:     "Mostrar _MENU_ Elementos",
                    info:           "Mostrando de _START_ a _END_ registros de un total de _TOTAL_ registros",
                    //infoEmpty:      "Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments",
                    infoFiltered:   ".",
                    infoPostFix:    "",
                    loadingRecords: "Cargando Registros...",
                    zeroRecords:    "No existen registros disponibles",
                    emptyTable:     "No existen registros disponibles",
                    paginate: {
                        first:      "Primera",
                        previous:   "Anterior",
                        next:       "Siguiente",
                        last:       "Ultima"
                    }
                } 
            });

            $(document).keypressAction({actions: [{ key: 'c', route: " {{ route('admin.contabilidad.cuenta.create') }} " }]});
        });
    </script>
@stop
